import React, { useState, useEffect } from 'react';
import { ViewState, Listing, Category } from './types';
import { MOCK_LISTINGS, CATEGORY_LABELS } from './constants';
import { BigButton, ActionButton } from './components/UI';
import { ListingCard } from './components/ListingCard';
import { SmartLivestockForm } from './components/SmartLivestockForm';
import { SimpleForm } from './components/SimpleForms';
import { Home, ShoppingBag, User, Heart, ArrowLeft, Search, SlidersHorizontal, PlusCircle } from 'lucide-react';

export default function App() {
  // State
  const [view, setView] = useState<ViewState>('HOME');
  const [listings, setListings] = useState<Listing[]>(MOCK_LISTINGS);
  const [savedIds, setSavedIds] = useState<string[]>([]);
  const [filterCategory, setFilterCategory] = useState<Category>('LIVESTOCK');
  const [searchQuery, setSearchQuery] = useState('');

  // Persist Data (Simple MVP offline mode)
  useEffect(() => {
    const saved = localStorage.getItem('livestock_app_data');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.listings) setListings(parsed.listings);
        if (parsed.savedIds) setSavedIds(parsed.savedIds);
      } catch (e) { console.error("Data load error", e); }
    } else {
        // Init with mocks if empty
        setListings(MOCK_LISTINGS);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('livestock_app_data', JSON.stringify({ listings, savedIds }));
  }, [listings, savedIds]);

  // Handlers
  const handleCreateListing = (data: Partial<Listing>) => {
    const newListing: Listing = {
      ...data as Listing,
      id: Date.now().toString(),
      createdAt: Date.now(),
    };
    setListings(prev => [newListing, ...prev]);
    setView('SAVED'); // Go to "My Listings" (simulated by saved/history for now)
    setSavedIds(prev => [...prev, newListing.id]); // Auto-save own listing
  };

  const toggleSave = (id: string) => {
    setSavedIds(prev => prev.includes(id) ? prev.filter(s => s !== id) : [...prev, id]);
  };

  const filteredListings = listings.filter(l => {
    if (view === 'BUYER_LIST' && l.type !== filterCategory) return false;
    if (view === 'SAVED' && !savedIds.includes(l.id)) return false;
    if (searchQuery && !l.description?.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  // --- Views Renders ---

  const renderHome = () => (
    <div className="flex flex-col h-full justify-center px-6 space-y-8 animate-fade-in">
      <div className="text-center mb-4">
        <h1 className="text-4xl font-extrabold text-emerald-900 tracking-tight mb-2">Qazaq Market</h1>
        <p className="text-emerald-700 text-lg">Создай. Найди. Сохрани.</p>
      </div>

      <div className="space-y-4 w-full max-w-sm mx-auto">
        <BigButton 
          title="Я Продавец" 
          subtitle="Создать объявление"
          onClick={() => setView('SELLER_HUB')}
          colorClass="bg-white text-emerald-800 hover:bg-emerald-50"
          icon={<PlusCircle />}
        />
        <BigButton 
          title="Я Покупатель" 
          subtitle="Найти скот или мясо"
          onClick={() => setView('BUYER_HUB')}
          colorClass="bg-emerald-600 text-white hover:bg-emerald-700"
          icon={<Search />}
        />
        <BigButton 
          title="Сохранённые" 
          onClick={() => setView('SAVED')}
          colorClass="bg-emerald-800 text-white hover:bg-emerald-900"
          icon={<Heart />}
        />
      </div>
      
      <p className="text-center text-xs text-emerald-600 opacity-60 mt-auto">
        Работает офлайн • Автосохранение
      </p>
    </div>
  );

  const renderSellerHub = () => (
    <div className="px-6 py-8">
      <div className="flex items-center mb-8">
        <button onClick={() => setView('HOME')} className="p-2 -ml-2 text-gray-600"><ArrowLeft /></button>
        <h2 className="text-3xl font-bold ml-2 text-gray-800">Что продаём?</h2>
      </div>
      
      <div className="grid grid-cols-1 gap-4">
        <BigButton 
          title="Живой скот" 
          icon="🐄"
          onClick={() => setView('SELLER_FORM_LIVESTOCK')}
          colorClass="bg-amber-100 text-amber-900 hover:bg-amber-200 h-40"
        />
        <BigButton 
          title="Мясо" 
          icon="🥩"
          onClick={() => setView('SELLER_FORM_MEAT')}
          colorClass="bg-red-100 text-red-900 hover:bg-red-200 h-40"
        />
        <BigButton 
          title="Молоко / Продукты" 
          icon="🥛"
          onClick={() => setView('SELLER_FORM_DAIRY')}
          colorClass="bg-blue-100 text-blue-900 hover:bg-blue-200 h-40"
        />
      </div>
    </div>
  );

  const renderBuyerHub = () => (
    <div className="px-6 py-8">
      <div className="flex items-center mb-8">
        <button onClick={() => setView('HOME')} className="p-2 -ml-2 text-gray-600"><ArrowLeft /></button>
        <h2 className="text-3xl font-bold ml-2 text-gray-800">Что ищем?</h2>
      </div>

      <div className="grid grid-cols-1 gap-4">
         <BigButton 
          title="Живой скот" 
          icon="🐄"
          onClick={() => { setFilterCategory('LIVESTOCK'); setView('BUYER_LIST'); }}
          colorClass="bg-white border-2 border-emerald-100 text-gray-800 hover:bg-emerald-50 h-32"
        />
         <BigButton 
          title="Мясо / Согым" 
          icon="🥩"
          onClick={() => { setFilterCategory('MEAT'); setView('BUYER_LIST'); }}
          colorClass="bg-white border-2 border-emerald-100 text-gray-800 hover:bg-emerald-50 h-32"
        />
         <BigButton 
          title="Молочная продукция" 
          icon="🥛"
          onClick={() => { setFilterCategory('DAIRY'); setView('BUYER_LIST'); }}
          colorClass="bg-white border-2 border-emerald-100 text-gray-800 hover:bg-emerald-50 h-32"
        />
      </div>
    </div>
  );

  const renderList = (title: string, isSavedView: boolean) => (
    <div className="flex flex-col h-full bg-gray-50">
      <div className="bg-white px-4 py-4 shadow-sm z-10 sticky top-0">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
             <button onClick={() => setView(isSavedView ? 'HOME' : 'BUYER_HUB')} className="p-2 -ml-2 text-gray-600"><ArrowLeft /></button>
             <h2 className="text-xl font-bold ml-2">{title}</h2>
          </div>
          {!isSavedView && <button className="p-2 bg-gray-100 rounded-full"><SlidersHorizontal size={20}/></button>}
        </div>
        
        <div className="relative">
          <input 
            type="text" 
            placeholder="Поиск (например: корова 2 года)" 
            className="w-full pl-10 pr-4 py-3 bg-gray-100 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <Search className="absolute left-3 top-3.5 text-gray-400" size={18} />
        </div>
      </div>

      <div className="flex-grow overflow-y-auto px-4 py-4 space-y-4">
        {filteredListings.length === 0 ? (
          <div className="text-center text-gray-400 mt-20">
            <p className="text-4xl mb-2">🍃</p>
            <p>Список пуст</p>
          </div>
        ) : (
          filteredListings.map(l => (
            <ListingCard 
              key={l.id} 
              listing={l} 
              onSave={toggleSave} 
              isSaved={savedIds.includes(l.id)} 
            />
          ))
        )}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 font-sans text-gray-800 md:max-w-md md:mx-auto md:shadow-2xl md:min-h-[800px] md:h-[90vh] md:overflow-hidden md:rounded-3xl relative">
      {/* Content Area */}
      <div className="h-full overflow-y-auto scrollbar-hide">
        {view === 'HOME' && renderHome()}
        {view === 'SELLER_HUB' && renderSellerHub()}
        {view === 'SELLER_FORM_LIVESTOCK' && <div className="p-6"><SmartLivestockForm onBack={() => setView('SELLER_HUB')} onSubmit={handleCreateListing} /></div>}
        {view === 'SELLER_FORM_MEAT' && <div className="p-6"><SimpleForm type="MEAT" onBack={() => setView('SELLER_HUB')} onSubmit={handleCreateListing} /></div>}
        {view === 'SELLER_FORM_DAIRY' && <div className="p-6"><SimpleForm type="DAIRY" onBack={() => setView('SELLER_HUB')} onSubmit={handleCreateListing} /></div>}
        {view === 'BUYER_HUB' && renderBuyerHub()}
        {view === 'BUYER_LIST' && renderList(CATEGORY_LABELS[filterCategory], false)}
        {view === 'SAVED' && renderList('Избранное / Мои', true)}
      </div>
    </div>
  );
}